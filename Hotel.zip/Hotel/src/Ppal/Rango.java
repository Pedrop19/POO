package Ppal;

public enum Rango {
	LIMPIADOR, COCINERO, GERENTE
}
