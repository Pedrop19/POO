package Ppal;

public enum Categoria {
	NORMAL, DUPLEX, VIP, DELUXE
}
