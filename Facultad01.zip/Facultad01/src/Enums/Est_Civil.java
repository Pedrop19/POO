package Enums;

public enum Est_Civil {
    SOLTERO, CASADO, VIUDO, SEPARADO, DIVORCIADO
}
